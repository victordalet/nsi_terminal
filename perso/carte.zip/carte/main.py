from bataille import *

def main():
	run()

main()